/* 3B başlık sahnesi: üst üste duran optik form kâğıtları, uçan balonlar, bir kurşun kalem.
   Yalnız süs: sayılar ve tablolar düz HTML. window.OyssSahne.baslat(THREE, kapsayici, {mobil}) */
(function () {
  'use strict';

  function css(ad, yedek) {
    var v = getComputedStyle(document.documentElement).getPropertyValue(ad).trim();
    return v || yedek;
  }
  // tohumlu sayı üreteci: her açılışta aynı kâğıt
  function rastgele(tohum) { var s = tohum >>> 0; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

  // Kâğıt dokusu: başlık şeridi, balon ızgarası, birkaçı doldurulmuş
  function kagitDokusu(THREE, tohum, renk, kucuk) {
    var W = 512, H = 1024, c = document.createElement('canvas');
    c.width = W; c.height = H;
    var g = c.getContext('2d');
    g.setTransform(1, 0, 0, 1024 / 768, 0, 0);            // 512x768 uzayında çiz, dikeyde esnet (kâğıt 1:1.5)
    g.fillStyle = renk.kagit; g.fillRect(0, 0, 512, 768);
    g.fillStyle = renk.sertit; g.fillRect(0, 0, 512, 70);   // üst şerit
    g.fillStyle = renk.sertit; g.fillRect(36, 26, 190, 14);
    g.fillStyle = renk.cizgi; g.fillRect(36, 92, 440, 3);
    var r = rastgele(tohum), sat = kucuk ? 11 : 14, sut = 4;
    for (var i = 0; i < sat; i++) {
      var y = 130 + i * 44;
      g.fillStyle = renk.mavi; g.font = '600 16px monospace'; g.textBaseline = 'middle';
      g.fillText(String(i + 1), 34, y);
      var dolu = Math.floor(r() * sut);
      for (var j = 0; j < sut; j++) {
        var x = 120 + j * 92;
        g.beginPath(); g.arc(x, y, 15, 0, Math.PI * 2);
        if (j === dolu) { g.fillStyle = r() > .72 ? renk.kirmizi : renk.mavi; g.fill(); }
        else { g.lineWidth = 3; g.strokeStyle = renk.cizgi; g.stroke(); }
      }
    }
    var t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 2;
    return t;
  }

  function baslat(THREE, kap, opt) {
    var mobil = !!opt.mobil;
    var renderer = new THREE.WebGLRenderer({ antialias: !mobil, alpha: true, powerPreference: 'low-power' });
    var dprTavan = mobil ? 1.5 : 2;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, dprTavan));
    renderer.setClearColor(0x000000, 0);
    kap.appendChild(renderer.domElement);

    var scene = new THREE.Scene();
    var cam = new THREE.PerspectiveCamera(32, 1, .1, 30);
    cam.position.set(0, 0, 7.4);

    var isik = new THREE.DirectionalLight(0xffffff, 2.2); isik.position.set(2, 3, 4); scene.add(isik);
    scene.add(new THREE.AmbientLight(0xffffff, 1.1));

    var grup = new THREE.Group(); scene.add(grup);
    var varlik = [];               // dispose için
    var kagitlar = [], balonlar = null, kalem = null;
    var mats = { kenar: null, balon: null, govde: null, tahta: null, uc: null };
    var dokular = [];

    function renkler() {
      var koyu = window.matchMedia('(prefers-color-scheme: dark)').matches;
      return {
        koyu: koyu,
        kagit: koyu ? '#dfe5f2' : '#ffffff',
        sertit: koyu ? '#9fb0d4' : '#c9d1e0',
        cizgi: koyu ? '#8d9ab8' : '#aab4c8',
        mavi: css('--accent', '#1d4ed8') === '#7aa5ff' ? '#2a5be0' : css('--accent', '#1d4ed8'),
        kirmizi: koyu ? '#d0343e' : css('--pen', '#b81f2a')
      };
    }

    var n = mobil ? 3 : 5;
    var geoKagit = new THREE.BoxGeometry(1, 1.5, .014);
    varlik.push(geoKagit);
    var rk = renkler();
    mats.kenar = new THREE.MeshLambertMaterial({ color: rk.koyu ? 0xaab4cc : 0xdfe4ee });
    varlik.push(mats.kenar);
    for (var i = 0; i < n; i++) {
      var tx = kagitDokusu(THREE, 11 + i * 7, rk, mobil);
      dokular.push(tx);
      var on = new THREE.MeshBasicMaterial({ map: tx });
      varlik.push(on, tx);
      var m = new THREE.Mesh(geoKagit, [mats.kenar, mats.kenar, mats.kenar, mats.kenar, on, mats.kenar]);
      var k = i - (n - 1) / 2;
      m.position.set(k * .72, -k * .06, -Math.abs(k) * .35);
      m.rotation.set(.05 * k, -.25 * k, -.09 * k);
      m.userData = { k: k, faz: i * 1.3 };
      grup.add(m); kagitlar.push(m);
    }

    // uçan balonlar (halka)
    var sayi = mobil ? 7 : 16;
    var geoBalon = new THREE.TorusGeometry(.1, .026, mobil ? 8 : 10, mobil ? 16 : 24);
    mats.balon = new THREE.MeshLambertMaterial({ color: 0xffffff });
    varlik.push(geoBalon, mats.balon);
    balonlar = new THREE.InstancedMesh(geoBalon, mats.balon, sayi);
    var r = rastgele(5), tmp = new THREE.Object3D(), bilgi = [], renk = new THREE.Color();
    for (var b = 0; b < sayi; b++) {
      var p = { x: (r() - .5) * 3.4, y: (r() - .5) * 1.4, z: .5 + r() * 1.6, hiz: .2 + r() * .4, faz: r() * 6.28, boy: .7 + r() * .9 };
      bilgi.push(p);
      renk.set(b % 3 === 0 ? rk.kirmizi : (b % 3 === 1 ? rk.mavi : (rk.koyu ? '#e8ecf5' : '#172033')));
      balonlar.setColorAt(b, renk);
    }
    grup.add(balonlar);

    // kurşun kalem
    kalem = new THREE.Group();
    var gGovde = new THREE.CylinderGeometry(.05, .05, 1.5, 6);
    var gTahta = new THREE.ConeGeometry(.05, .2, 6);
    var gUc = new THREE.ConeGeometry(.018, .07, 6);
    mats.govde = new THREE.MeshLambertMaterial({ color: rk.kirmizi });
    mats.tahta = new THREE.MeshLambertMaterial({ color: 0xd9b27c });
    mats.uc = new THREE.MeshLambertMaterial({ color: 0x2a2f3a });
    varlik.push(gGovde, gTahta, gUc, mats.govde, mats.tahta, mats.uc);
    var govde = new THREE.Mesh(gGovde, mats.govde);
    var tahta = new THREE.Mesh(gTahta, mats.tahta); tahta.position.y = -.85;
    tahta.rotation.x = Math.PI;
    var uc = new THREE.Mesh(gUc, mats.uc); uc.position.y = -.99; uc.rotation.x = Math.PI;
    kalem.add(govde, tahta, uc);
    kalem.position.set(1.1, -.2, 1.0); kalem.rotation.set(0, 0, .85); kalem.scale.setScalar(.62);
    grup.add(kalem);

    function renkleriYenile() {
      if (kalici) return;
      var c = renkler();
      mats.kenar.color.set(c.koyu ? 0xaab4cc : 0xdfe4ee);
      mats.govde.color.set(c.kirmizi);
      dokular.forEach(function (t, i) { t.dispose(); });
      for (var i = 0; i < kagitlar.length; i++) {
        var yeni = kagitDokusu(THREE, 11 + i * 7, c, mobil);
        var mt = kagitlar[i].material[4]; mt.map.dispose(); mt.map = yeni; mt.needsUpdate = true; dokular[i] = yeni;
      }
      var col = new THREE.Color();
      for (var b = 0; b < sayi; b++) {
        col.set(b % 3 === 0 ? c.kirmizi : (b % 3 === 1 ? c.mavi : (c.koyu ? '#e8ecf5' : '#172033')));
        balonlar.setColorAt(b, col);
      }
      balonlar.instanceColor.needsUpdate = true;
      ciz(performance.now());
    }
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    if (mq.addEventListener) mq.addEventListener('change', renkleriYenile);

    // boyut
    var gen = 1, yuk = 1;
    function boyutla() {
      if (kalici) return;
      var w = kap.clientWidth || 300, h = kap.clientHeight || 200;
      if (w === gen && h === yuk) return;
      gen = w; yuk = h;
      renderer.setSize(w, h, false);
      renderer.domElement.style.width = '100%'; renderer.domElement.style.height = '100%';
      cam.aspect = w / h;
      cam.fov = cam.aspect < 1.2 ? 36 : 32;
      cam.position.z = w < 600 ? 4.2 : (cam.aspect < 1.2 ? 7.6 : 6.9);
      cam.updateProjectionMatrix();
      ciz(performance.now());
    }

    // imleç / dokunma eğimi
    var hx = 0, hy = 0, ax = 0, ay = 0;
    function imlec(e) {   // sahne duraklamışken de hedefi günceller (yalnız çizmez); bırakılınca dinleyici kalkar
      var r2 = kap.getBoundingClientRect();
      hx = Math.max(-1, Math.min(1, ((e.clientX - r2.left) / r2.width - .5) * 2));
      hy = Math.max(-1, Math.min(1, ((e.clientY - r2.top) / r2.height - .5) * 2));
    }
    window.addEventListener('pointermove', imlec, { passive: true });

    var t0 = performance.now(), son = 0, calisiyor = false, kalici = false, rafId = 0, gorunur = true, sekmeAcik = !document.hidden;
    var aralik = mobil ? 33 : 16;
    var bilgiNesne = { mobil: mobil, dpr: renderer.getPixelRatio(), kagit: n, balon: sayi, calisiyor: false, kare: 0, durmaSayisi: 0 };
    window.__oyssSahneBilgi = bilgiNesne;

    function ciz(ms) {
      if (kalici) return;
      var t = (ms - t0) / 1000;
      ax += (hx - ax) * .06; ay += (hy - ay) * .06;
      grup.rotation.y = Math.sin(t * .35) * .16 + ax * .35;
      grup.rotation.x = Math.cos(t * .27) * .06 + ay * .18;
      for (var i = 0; i < kagitlar.length; i++) {
        var m = kagitlar[i], u = m.userData;
        m.position.y = -u.k * .06 + Math.sin(t * .8 + u.faz) * .06;
        m.rotation.z = -.09 * u.k + Math.sin(t * .5 + u.faz) * .02;
      }
      for (var b = 0; b < sayi; b++) {
        var p = bilgi[b];
        tmp.position.set(p.x + Math.sin(t * p.hiz + p.faz) * .25, p.y + Math.cos(t * p.hiz * 1.3 + p.faz) * .25, p.z);
        tmp.rotation.set(t * p.hiz + p.faz, t * p.hiz * .7, 0);
        tmp.scale.setScalar(p.boy);
        tmp.updateMatrix();
        balonlar.setMatrixAt(b, tmp.matrix);
      }
      balonlar.instanceMatrix.needsUpdate = true;
      kalem.rotation.y = t * .6;
      kalem.position.y = -.2 + Math.sin(t * .9) * .08;
      renderer.render(scene, cam);
      bilgiNesne.kare++;
      bilgiNesne.cagri = renderer.info.render.calls; bilgiNesne.ucgen = renderer.info.render.triangles;
    }
    function dongu(ms) {
      if (!calisiyor) return;
      rafId = requestAnimationFrame(dongu);
      if (ms - son < aralik) return;
      son = ms; ciz(ms);
    }
    function surdur() { if (kalici || calisiyor || !gorunur || !sekmeAcik) return; calisiyor = true; bilgiNesne.calisiyor = true; rafId = requestAnimationFrame(dongu); }
    function durdur() { if (!calisiyor) return; calisiyor = false; bilgiNesne.calisiyor = false; bilgiNesne.durmaSayisi++; cancelAnimationFrame(rafId); }

    var io = null, ro = null;
    if ('IntersectionObserver' in window) {
      io = new IntersectionObserver(function (es) { gorunur = es[0].isIntersecting; gorunur ? surdur() : durdur(); });
      io.observe(kap);
    }
    function gorunurlukDeg() { sekmeAcik = !document.hidden; sekmeAcik ? surdur() : durdur(); }
    document.addEventListener('visibilitychange', gorunurlukDeg);
    if ('ResizeObserver' in window) { ro = new ResizeObserver(boyutla); ro.observe(kap); } else window.addEventListener('resize', boyutla);

    // bağlam kaybolursa yeniden kurmayız: sahneyi kalıcı olarak kaldırıp sade arka plana düşeriz
    function birak(durumAdi) {
      if (kalici) return;
      durdur(); kalici = true;                  // bundan sonra hiçbir yol renderer'a dokunmaz
      window.removeEventListener('pointermove', imlec);
      window.removeEventListener('resize', boyutla);
      document.removeEventListener('visibilitychange', gorunurlukDeg);
      if (io) io.disconnect();
      if (ro) ro.disconnect();
      if (mq.removeEventListener) mq.removeEventListener('change', renkleriYenile);
      if (azHareketMq.removeEventListener) azHareketMq.removeEventListener('change', azHareketDeg);
      if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
      kap.classList.add('sahne-yok'); kap.setAttribute('data-sahne', durumAdi);
      try { renderer.dispose(); } catch (e) { /* bağlam zaten kayıp: dispose hata verebilir, önemsiz */ }
    }
    renderer.domElement.addEventListener('webglcontextlost', function () { birak('baglam-kayip'); });
    var azHareketMq = window.matchMedia('(prefers-reduced-motion: reduce)');
    function azHareketDeg() { if (azHareketMq.matches) birak('az-hareket'); }
    if (azHareketMq.addEventListener) azHareketMq.addEventListener('change', azHareketDeg);

    boyutla();
    ciz(performance.now());
    surdur();
    kap.setAttribute('data-sahne', 'hazir');
  }

  window.OyssSahne = { baslat: baslat };
})();
