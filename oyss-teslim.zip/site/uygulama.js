/* OYSS Rehberi: arayüz. Veri window.OYSS (veri.js). Sınıf -> ders -> yazılı -> senaryolar.
   Tablolar ve sayılar düz HTML; 3B sahne (sahne.js + three.js) yalnız süs, ilk boyamadan sonra yüklenir. */
(function () {
  'use strict';
  var V = window.OYSS;
  var $ = function (id) { return document.getElementById(id); };
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
  function satirlar(s) { // çok satırlı konu: her satır ayrı satır
    return String(s).split('\n').map(function (l) { return '<span>' + esc(l) + '</span>'; }).join('');
  }
  var azHareketMq = window.matchMedia('(prefers-reduced-motion: reduce)');
  var azHareket = azHareketMq.matches;          // canlı: aşağıdaki dinleyici günceller
  var sahneZorlaYok = /[?&]sahne=yok(&|$)/.test(location.search);   // test: WebGL yoluna hiç girme

  if (!V) { $('gorunum').innerHTML = '<div class="panel"><div class="not"><b>Veri yüklenemedi.</b> veri.js dosyası sayfayla aynı klasörde olmalı.</div></div>'; return; }

  var durum = { sinif: V.siniflar[0].sinif, ders: null, yaz: 0, gor: 'kart', sen: null };

  function sinifVeri(n) { for (var i = 0; i < V.siniflar.length; i++) if (V.siniflar[i].sinif === n) return V.siniflar[i]; return V.siniflar[0]; }
  function mevcut() {
    var sn = sinifVeri(durum.sinif);
    var ders = sn.dersler.filter(function (d) { return d.id === durum.ders; })[0] || sn.dersler[0];
    durum.ders = ders.id;
    if (durum.yaz >= ders.yazililar.length) durum.yaz = 0;
    return { sn: sn, ders: ders, y: ders.yazililar[durum.yaz] };
  }

  /* ---------- adres (#9/matematik/2/tablo) ---------- */
  function hashOku() {
    // her okumada varsayılandan başla: bozuk ya da eksik adres panelin boş kalmasına yol açmasın
    durum.sinif = V.siniflar[0].sinif; durum.ders = null; durum.yaz = 0; durum.gor = 'kart'; durum.sen = null;
    var ham = (location.hash || '').slice(1), p;
    try { p = decodeURIComponent(ham).split('/'); } catch (e) { return; }
    var n = parseInt(p[0], 10);
    if (V.siniflar.some(function (s) { return s.sinif === n; })) durum.sinif = n;
    if (p[1]) durum.ders = p[1];
    var yz = parseInt(p[2], 10); if (yz === 1 || yz === 2) durum.yaz = yz - 1;
    if (p[3] === 'tablo') durum.gor = 'tablo';
  }
  function hashYaz() {
    try { history.replaceState(null, '', '#' + durum.sinif + '/' + durum.ders + '/' + (durum.yaz + 1) + '/' + durum.gor); } catch (e) { /* file:// bazı tarayıcılarda izin vermez */ }
  }

  /* ---------- üst bilgi ---------- */
  function bilgiYaz(sn) {
    $('bilgi').innerHTML =
      '<li><b>' + esc(V.genel.sistem_acilis) + '</b> sistem açılış tarihi</li>' +
      '<li><b>' + V.genel.puan + ' puan</b> üzerinden değerlendirme</li>' +
      '<li><b>' + sn.dersler.length + ' ders</b> için konu-soru dağılımı</li>' +
      '<li>Senaryoyu <b>okul zümresi</b> seçer</li>';
  }

  /* ---------- seçiciler ---------- */
  function seciciler(m) {
    $('siniflar').innerHTML = V.siniflar.map(function (s) {
      var alt = s.kapsam === 'oyss' ? s.dersler.length + ' ders' : 'OYSS dışı';
      return '<button type="button" data-k="s' + s.sinif + '" data-sinif="' + s.sinif + '" aria-pressed="' + (s.sinif === durum.sinif) + '">' +
        s.sinif + '.<small>' + alt + '</small></button>';
    }).join('');
    $('dersler').innerHTML = m.sn.dersler.map(function (d) {
      return '<button type="button" class="chip" data-k="d' + esc(d.id) + '" data-ders="' + esc(d.id) + '" aria-pressed="' + (d.id === m.ders.id) + '">' + esc(d.ad) + '</button>';
    }).join('');
    var dn = $('dersnot');
    if (m.sn.kapsam_disi && m.sn.kapsam_disi.length) {
      dn.hidden = false;
      dn.textContent = m.sn.kapsam_disi.map(function (k) { return k.aciklama; }).join(' · ');
    } else { dn.hidden = true; dn.textContent = ''; }
    $('yazililar').innerHTML = m.ders.yazililar.map(function (y, i) {
      return '<button type="button" data-k="y' + i + '" data-yaz="' + i + '" aria-pressed="' + (i === durum.yaz) + '">' + esc(y.ad) + '</button>';
    }).join('');
  }

  /* ---------- yardımcılar ---------- */
  function topMax(y) { var mx = 1; y.satirlar.forEach(function (r) { r.c.forEach(function (v) { if (v > mx) mx = v; }); }); return mx; }
  function grupla(rows) { // ust'a göre, ilk görünme sırasıyla
    var sira = [], harita = {};
    rows.forEach(function (r) {
      var k = r.ust == null ? '' : r.ust;
      if (!harita.hasOwnProperty(k)) { harita[k] = []; sira.push(k); }
      harita[k].push(r);
    });
    return sira.map(function (k) { return { ust: k, rows: harita[k] }; });
  }
  function ortakKonu(rows) { // grupta herkes aynı konuyu paylaşıyorsa bir kez göster
    var set = {}, n = 0;
    rows.forEach(function (r) { if (r.konu != null && !set[r.konu]) { set[r.konu] = 1; n++; } });
    var tumu = rows.every(function (r) { return r.konu != null; });
    return (n === 1 && tumu && rows.length > 1) ? rows[0].konu : null;
  }
  function takvimHtml(sn, y) {
    if (y.tur === 'ulke_geneli') {
      return '<div class="tarih"><mark>' + esc(y.tarih) + '</mark><small>Ülke geneli ortak yazılı sınav takvimi' +
        (y.tarih_kaynak_url ? ' · <a href="' + esc(y.tarih_kaynak_url) + '" target="_blank" rel="noopener">resmî takvim</a>' : '') + '</small></div>';
    }
    if (y.takvim_gunu) {
      return '<div class="tarih"><mark>' + esc(y.takvim_gunu) + '</mark><small>Okul geneli OYSS takviminde bu dersin 1. yazılı günü · <a href="' +
        esc(y.takvim_kaynak_url) + '" target="_blank" rel="noopener">resmî takvim</a></small></div>';
    }
    if (sn.kapsam !== 'oyss') return '<div class="tarih"><small>12. sınıf için resmî OYSS takvimi yok.</small></div>';
    return '<div class="tarih"><small>Bu yazılının günü resmî kaynaklarda henüz yok.</small></div>';
  }

  /* ---------- senaryo kartları ---------- */
  function kartHtml(y, i, mx) {
    var sat = y.satirlar.filter(function (r) { return r.c[i] > 0; });
    var yok = y.satirlar.filter(function (r) { return !r.c[i]; }).length;
    var gruplar = grupla(sat).map(function (g) {
      var ok = ortakKonu(g.rows);
      return '<section class="grup"><h4>' + esc(g.ust || 'Genel') + '</h4>' +
        (ok ? '<p class="konu">' + satirlar(ok) + '</p>' : '') +
        '<ul class="ogeler">' + g.rows.map(function (r) {
          var kk = (!ok && r.konu != null) ? '<span class="konu-satir" style="display:block;font-size:12.5px;color:var(--muted)">' + satirlar(r.konu) + '</span>' : '';
          return '<li><div>' + (r.kod ? '<span class="kod">' + esc(r.kod) + '</span>' : '') + kk +
            '<span class="metin" style="display:block">' + esc(r.metin) + '</span></div>' +
            '<div class="sag"><b class="say">' + r.c[i] + '</b><span class="cubuk" role="img" aria-label="' + r.c[i] + ' soru"><i style="width:' + Math.round(r.c[i] / mx * 100) + '%"></i></span></div></li>';
        }).join('') + '</ul></section>';
    }).join('');
    return '<li class="kart3d"><article class="kart-ic" aria-labelledby="sen' + i + '">' +
      '<div class="kart-bas"><span class="balon" aria-hidden="true">' + (i + 1) + '</span><div><h3 id="sen' + i + '">Senaryo ' + (i + 1) + '</h3>' +
      '<p><span class="sayi">' + y.toplam[i] + '</span> soru · ' + sat.length + ' öğrenme çıktısı</p></div></div>' +
      gruplar +
      (yok ? '<p class="kart-alt">Bu senaryoda soru gelmeyen ' + yok + ' öğrenme çıktısı daha var (tabloda gör).</p>' : '') +
      '</article></li>';
  }

  /* ---------- karşılaştırma tablosu ---------- */
  function tabloHtml(m) {
    var y = m.y, mx = topMax(y), n = y.senaryo_sayisi, sec = durum.sen;
    var th = '';
    for (var i = 0; i < n; i++) th += '<th class="n' + (sec === i ? ' sec' : '') + '" scope="col"><button type="button" class="bub" data-sen="' + i + '" aria-pressed="' + (sec === i) + '" data-k="tb' + i + '" aria-label="Senaryo ' + (i + 1) + ' sütununu vurgula" style="min-width:44px;padding:0">' + (i + 1) + '</button></th>';
    var body = '';
    grupla(y.satirlar).forEach(function (g) {
      body += '<tr class="grup-satir"><th colspan="' + (n + 1) + '" scope="colgroup">' + esc(g.ust || 'Genel') + '</th></tr>';
      g.rows.forEach(function (r) {
        var hucre = '';
        for (var i = 0; i < n; i++) {
          var v = r.c[i];
          hucre += '<td class="n ' + (v ? '' : 'z') + (sec === i ? ' sec' : '') + '" style="--v:' + (v / mx).toFixed(2) + '"' + (v ? '' : ' aria-label="0"') + '>' + (v || '–') + '</td>';
        }
        body += '<tr' + (r.bos ? ' class="bos"' : '') + '><th class="ilk" scope="row">' +
          (r.kod ? '<span class="kod">' + esc(r.kod) + '</span>' : '') +
          '<span class="metin">' + esc(r.metin) + '</span>' +
          (r.konu != null ? '<span class="konu">' + satirlar(r.konu) + '</span>' : '') +
          (r.bos ? '<span class="soluk">bu yazılıda soru yok</span>' : '') + '</th>' + hucre + '</tr>';
      });
    });
    var foot = '';
    for (var j = 0; j < n; j++) foot += '<td class="n' + (sec === j ? ' sec' : '') + '">' + y.toplam[j] + '</td>';
    return '<div class="tablokap" tabindex="0" role="region" aria-label="Senaryo karşılaştırma tablosu, yatay kaydırılabilir"><table>' +
      '<caption>Tüm senaryolar · renk koyuldukça o çıktıdan daha çok soru</caption>' +
      '<thead><tr><th class="ilk" scope="col">Öğrenme çıktısı</th>' + th + '</tr></thead><tbody>' + body +
      '</tbody><tfoot><tr><th class="ilk" scope="row">Toplam soru</th>' + foot + '</tr></tfoot></table></div>';
  }

  function bosListe(y) {
    var b = y.satirlar.filter(function (r) { return r.bos; });
    if (!b.length) return '';
    return '<details class="bos-liste"><summary>Bu yazılıda hiçbir senaryoda soru gelmeyen ' + b.length + ' çıktı</summary><ul>' +
      b.map(function (r) { return '<li>' + (r.kod ? '<span class="kod">' + esc(r.kod) + '</span>' : '') + esc(r.metin) + (r.ust ? ' <small>(' + esc(r.ust) + ')</small>' : '') + '</li>'; }).join('') +
      '</ul></details>';
  }

  /* ---------- ana görünüm ---------- */
  function gorunumYaz(m) {
    var y = m.y, ders = m.ders, sn = m.sn, html = '';
    html += '<div class="panel">';
    if (sn.uyari) html += '<div class="uyari12" role="note"><b>Önemli.</b> ' + esc(sn.uyari) + '</div>';
    html += '<div class="panel-bas"><h2>' + esc(ders.ad) + ' · ' + esc(y.ad) + '</h2>';
    if (y.tur === 'ulke_geneli') {
      html += '<p>Ülke geneli ortak sınav</p></div>' + takvimHtml(sn, y) +
        '<div class="not"><b>Tablo henüz yok.</b> Bu yazılı Bakanlık takvimiyle bütün okullarda aynı gün yapılır, bu yüzden okul zümresi senaryo seçmez. Konu soru dağılım tablosu sınav öncesi kılavuzla birlikte yayımlanacak.</div>';
    } else {
      var n = y.senaryo_sayisi, lo = Math.min.apply(null, y.toplam), hi = Math.max.apply(null, y.toplam);
      var aralik = lo === hi ? lo + ' soru' : lo + '–' + hi + ' soru';
      var bosSay = y.satirlar.filter(function (r) { return r.bos; }).length;
      html += '<p>' + n + ' senaryo · ' + y.satirlar.length + ' öğrenme çıktısı · senaryo başına ' + aralik + '</p></div>' + takvimHtml(sn, y);
      // araç çubuğu
      var bal = '<span id="sen-etiket">Senaryo</span><button type="button" class="bub" data-k="sTum" data-sen="tum" aria-pressed="' + (durum.sen === null) + '">Tümü</button>';
      for (var i = 0; i < n; i++) bal += '<button type="button" class="bub" data-k="sb' + i + '" data-sen="' + i + '" aria-pressed="' + (durum.sen === i) + '" aria-label="Senaryo ' + (i + 1) + '">' + (i + 1) + '</button>';
      html += '<div class="arac"><div class="balonlar" role="group" aria-labelledby="sen-etiket">' + bal + '</div>' +
        '<div class="seg" role="group" aria-label="Görünüm"><button type="button" data-k="gk" data-gor="kart" aria-pressed="' + (durum.gor === 'kart') + '">Senaryo kartları</button>' +
        '<button type="button" data-k="gt" data-gor="tablo" aria-pressed="' + (durum.gor === 'tablo') + '">Karşılaştırma</button></div></div>';
      if (durum.gor === 'kart') {
        var mx = topMax(y), kartlar = '';
        for (var k = 0; k < n; k++) if (durum.sen === null || durum.sen === k) kartlar += kartHtml(y, k, mx);
        html += '<ul class="kartlar' + (durum.sen !== null ? ' tek' : '') + '" id="kartlar">' + kartlar + '</ul>' + bosListe(y);
      } else {
        html += tabloHtml(m);
      }
      html += '<p class="toplam-not">' + (y.toplam_kaynak === 'kaynak'
        ? 'Toplam satırı resmî tabloda etiketsiz olarak var ve satır toplamlarıyla birebir aynı.'
        : 'Toplamlar satırlardan hesaplandı, resmî tabloda toplam satırı yok.') + '</p>';
    }
    html += '<p class="ders-bag">Bu dersin resmî tablosu: <a href="' + esc(ders.kaynak_url) + '" target="_blank" rel="noopener">ÖDSGM tablosu (xlsx)</a>. Dosyada her sınıf ayrı sayfadır; ' + sn.sinif + '. sınıf sayfasına bak.</p>';
    html += '</div>';
    $('gorunum').innerHTML = html;
  }

  /* ---------- örnek sorular ---------- */
  function ornekYaz(m) {
    var liste = (m.sn.ornek_sorular || []).filter(function (q) {
      return (!q.ders_id || q.ders_id === m.ders.id) && (!q.yazili || q.yazili === m.y.ad);
    });
    var h = '<h2 id="h-ornek">Örnek sorular</h2>';
    if (!liste.length) {
      h += '<p><b>Bu yıl için örnek soru yok.</b> MEB/ÖDSGM, 2026-2027 OYSS için örnek soru yayımlamadı. Sorular kapalı bir soru havuzundan geliyor; havuz yalnız öğretmenlere, sınavdan ' + V.genel.havuz_gun_once + ' gün önce açılıyor. Seçilen senaryodaki iki öğrenme çıktısı için iki açık uçlu soruyu öğretmenler yazıyor, kalanlar Bakanlık havuzundan geliyor (OYSS Uygulama Kılavuzu).</p>' +
        '<p>Örnek soru yayımlanırsa bu bölümde ders ve yazılıya göre görünür. Önceki yıllara ait örnek soru kitapçıkları <a href="https://odsgm.meb.gov.tr/www/ornek-soru-kitapciklari/kategori/151" target="_blank" rel="noopener">ÖDSGM sitesinde</a> var; ama eski sisteme ve eski kazanım kodlarına göre hazırlandıkları için buradaki tablolarla eşleşmez.</p>';
    } else {
      h += liste.map(function (q) {
        return '<article class="soru-kart"><div class="soru-meta">' + (q.eski_sistem ? '<span class="rozet">eski sistem</span>' : '') +
          (q.kod ? '<span class="kod" style="font-family:var(--f-mono)">' + esc(q.kod) + '</span>' : '') +
          (q.yazili ? '<span>' + esc(q.yazili) + '</span>' : '') + '</div>' +
          '<div class="metin">' + esc(q.soru) + '</div>' +
          (q.gorsel_var ? '<p class="toplam-not">Bu soruda şekil ya da tablo var; kaynağa bak.</p>' : '') +
          (q.cevap_anahtari ? '<details><summary style="min-height:44px;display:flex;align-items:center;cursor:pointer">Cevap anahtarı</summary><div class="metin">' + esc(q.cevap_anahtari) + '</div></details>' : '') +
          '<div class="soru-meta">' + (q.kaynak_url ? '<a href="' + esc(q.kaynak_url) + '" target="_blank" rel="noopener">Kaynak</a>' : '') + (q.sayfa ? '<span>sayfa ' + esc(q.sayfa) + '</span>' : '') + '</div></article>';
      }).join('');
    }
    $('ornek').innerHTML = h;
  }

  /* ---------- kaynaklar + notlar (altbilgi) ---------- */
  function dipYaz(sn) {
    var h = '<details><summary>' + sn.sinif + '. sınıf kaynakları (' + sn.kaynaklar.length + ')</summary><ul>' +
      sn.kaynaklar.map(function (k) { return '<li><a href="' + esc(k.url) + '" target="_blank" rel="noopener">' + esc(k.ad) + '</a></li>'; }).join('') + '</ul></details>';
    if (sn.notlar && sn.notlar.length) {
      h += '<details><summary>' + sn.sinif + '. sınıf veri notları (' + sn.notlar.length + ')</summary><ul>' +
        sn.notlar.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul></details>';
    }
    $('kaynaklar').innerHTML = h;
  }

  /* ---------- çizim ---------- */
  function ciz() {
    var etkin = document.activeElement, anahtar = etkin && etkin.getAttribute ? etkin.getAttribute('data-k') : null;
    var m = mevcut();
    if (m.y.tur === 'ulke_geneli') durum.sen = null;
    else if (durum.sen !== null && durum.sen >= m.y.senaryo_sayisi) durum.sen = null;
    bilgiYaz(m.sn); seciciler(m); gorunumYaz(m); ornekYaz(m); dipYaz(m.sn); hashYaz();
    document.title = 'OYSS ' + m.sn.sinif + '. sınıf ' + m.ders.ad + ' ' + m.y.ad + ' · 2026-2027 1. dönem';
    if (anahtar) {
      var yeni = document.querySelector('[data-k="' + anahtar.replace(/"/g, '') + '"]');
      if (yeni) yeni.focus({ preventScroll: true });
    }
  }

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-sinif')) { durum.sinif = +b.getAttribute('data-sinif'); durum.ders = null; durum.yaz = 0; durum.sen = null; ciz(); }
    else if (b.hasAttribute('data-ders')) { durum.ders = b.getAttribute('data-ders'); durum.yaz = 0; durum.sen = null; ciz(); }
    else if (b.hasAttribute('data-yaz')) { durum.yaz = +b.getAttribute('data-yaz'); durum.sen = null; ciz(); }
    else if (b.hasAttribute('data-gor')) { durum.gor = b.getAttribute('data-gor'); ciz(); }
    else if (b.hasAttribute('data-sen')) {
      var v = b.getAttribute('data-sen'); var yeni = v === 'tum' ? null : +v;
      durum.sen = (durum.sen === yeni) ? null : yeni;
      ciz();
    }
  });
  window.addEventListener('hashchange', function () { hashOku(); ciz(); });

  /* ---------- CSS 3B eğim (fare / dokunma) ---------- */
  var tiltKart = null, tiltRaf = 0, tiltSon = null;
  function tiltUygula() {
    tiltRaf = 0;
    if (!tiltSon) return;
    var e = tiltSon, k = e.target.closest ? e.target.closest('.kart3d') : null;
    if (tiltKart && tiltKart !== k) tiltSifirla(tiltKart);
    tiltKart = k;
    if (!k) return;
    var ic = k.firstElementChild, r = k.getBoundingClientRect();
    var px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5;
    ic.style.setProperty('--rx', (-py * 6).toFixed(2) + 'deg');
    ic.style.setProperty('--ry', (px * 8).toFixed(2) + 'deg');
    k.classList.add('etkin');
  }
  function tiltSifirla(k) {
    if (!k) return;
    k.firstElementChild.style.setProperty('--rx', '0deg'); k.firstElementChild.style.setProperty('--ry', '0deg');
    k.classList.remove('etkin');
  }
  var gv = $('gorunum');
  function tiltIste(e) { if (azHareket) return; tiltSon = e; if (!tiltRaf) tiltRaf = requestAnimationFrame(tiltUygula); }
  gv.addEventListener('pointermove', tiltIste, { passive: true });
  gv.addEventListener('pointerdown', tiltIste, { passive: true });
  ['pointerleave', 'pointerup', 'pointercancel'].forEach(function (t) {
    gv.addEventListener(t, function () { tiltSon = null; setTimeout(function () { tiltSifirla(tiltKart); tiltKart = null; }, t === 'pointerleave' ? 0 : 260); }, { passive: true });
  });
  function azHareketDegisti() {
    azHareket = azHareketMq.matches;
    if (azHareket) { tiltSon = null; document.querySelectorAll('.kart3d').forEach(tiltSifirla); tiltKart = null; }
  }
  if (azHareketMq.addEventListener) azHareketMq.addEventListener('change', azHareketDegisti);

  /* ---------- başlangıç ---------- */
  hashOku();
  ciz();
  $('gorunum').style.minHeight = '0';   // yalnız ilk boyamada yer ayırır (sayfa kaymasın)

  /* ---------- 3B sahne: ilk boyamadan sonra, koşullar uygunsa ---------- */
  function sahneKos() {
    var kap = $('sahne');
    kap.setAttribute('data-sahne', 'kontrol');
    if (sahneZorlaYok) { kap.classList.add('sahne-yok'); kap.setAttribute('data-sahne', 'sorgu-yok'); return; }
    if (azHareket) { kap.classList.add('sahne-yok'); kap.setAttribute('data-sahne', 'az-hareket'); return; }                         // sade arka plan
    if (navigator.connection && navigator.connection.saveData) { kap.classList.add('sahne-yok'); return; }
    var gl = null;
    try { var c = document.createElement('canvas'); gl = c.getContext('webgl2') || c.getContext('webgl'); if (gl) { var x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); } } catch (e) { gl = null; }
    if (!gl) { kap.classList.add('sahne-yok'); kap.setAttribute('data-sahne', 'webgl-yok'); return; }                                // WebGL yok
    function betik(src, ok, hata) { var s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = hata; document.head.appendChild(s); }
    function satirIci(id) { var t = $(id); if (!t) return false; var s = document.createElement('script'); s.text = t.textContent; document.head.appendChild(s); return true; }
    function baslat() {
      if (!window.THREE || !window.OyssSahne) { kap.classList.add('sahne-yok'); return; }
      var mobil = window.matchMedia('(max-width: 859px)').matches || window.matchMedia('(pointer: coarse)').matches;
      try { window.OyssSahne.baslat(window.THREE, kap, { mobil: mobil }); } catch (e) { kap.classList.add('sahne-yok'); }
    }
    function yukle() {
      kap.setAttribute('data-sahne', 'yukleniyor');
      var hata = function () { kap.classList.add('sahne-yok'); };
      var sahneHazir = function () {
        if (window.THREE) return baslat();
        if (satirIci('three-kaynak')) return baslat();
        betik('vendor/three.classic.min.js', baslat, hata);
      };
      if (window.OyssSahne) sahneHazir(); else betik('sahne.js', sahneHazir, hata);
    }
    var rc = kap.getBoundingClientRect();
    if (rc.bottom > -100 && rc.top < window.innerHeight + 100) yukle();   // zaten görünür
    else if ('IntersectionObserver' in window) {   // ekran dışıysa görünene kadar yükleme
      var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); yukle(); } }, { rootMargin: '100px' });
      io.observe(kap);
    } else yukle();
  }
  function gecikmeli() {
    setTimeout(sahneKos, 900);   // ilk boyama ve etkileşim hazır olduktan sonra
  }
  if (document.readyState === 'complete') gecikmeli(); else window.addEventListener('load', gecikmeli);
})();
